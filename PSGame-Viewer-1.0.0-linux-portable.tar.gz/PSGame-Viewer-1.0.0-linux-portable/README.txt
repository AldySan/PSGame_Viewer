PSGame-Viewer (portable)

Run ./psgame-viewer.sh. All settings and data stay inside this folder:
  PSGame-Viewer.ini   settings
  library.db          game library
  cache/              cover art cache
  batch_rename_*.log  rename revert logs

Optionally register the menu entry:
  xdg-desktop-menu install share/applications/psgame-viewer.desktop
