#!/bin/sh
# Portable launcher: resolves the runtime library path relative to this
# folder. Plugin and QML paths come from bin/qt.conf.
DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
export LD_LIBRARY_PATH="$DIR/lib:$LD_LIBRARY_PATH"
exec "$DIR/bin/psgame-viewer" "$@"
